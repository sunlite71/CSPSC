/*#include <stdio.h>
#include <stdlib.h>
*/
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
/*
int main(int argc, char *argv[]) {
	return 0;
}
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#define SIZE 35
#define MAX 250
#define LINELETH 52
#define SYMBOL struct _SYMBOL
#define LEN sizeof(Stack)
unsigned int u,v,w,e,i,j,l,E,F,g,LineCnt,ColCnt,IntConst,toknum;int k=1;int top=1;
char ch;char buff[LINELETH]={0};   float FloatConst;
int ETC,EFC,FTC,BTTC,BTFC,BF1TC,BF1FC,BETC,BEFC,BFTC,BFFC,BFFC1;
    ReadLine();
    FirstCh();
    Sort();
    RecogID();
    HandleCom();
    RecogDig();
    RecogStr();
    RecogDel();
    LookUp();
    SCANNER();
    SYNDITER();
    struct TokenName {
    	char*HeadP;//a pointer points to the head adddress of an ID or constant in wordstr
    	int IDlength;
	};
	enum TokenType {NUL,integer,real,chara,boolen};
	enum TokenKind {var,array,chconst,digconst,procedure,program};
   SYMBOL {
            struct TokenName name;
			enum TokenType type;
			enum TokenKind kind;
			union val {
				int Ival; //use this member when digit constant Is an integer
				double Fval;  //use this member when  digit constant Is an float
				SYMBOL*entry; //in synditer, use this in constdef
		           	  }Uval;
		  }SymbolList[SIZE]={0};
char WordStr[102];    //store ID or character constant for SymbolList
char*pStrlistTail=WordStr;
    enum Space {_};
struct Token {
	          int code;
	          union SelfVal{
	          	enum Space space;//if token is a reservedword or del, use this member
	          	SYMBOL*entryP;//if token is an ID or a constant, use this member
	          }Sval;
}tokArry[MAX]={0};   //TokenWord stored in tokArry[MAX]
SYMBOL*entryP= SymbolList; SYMBOL*entry= SymbolList;
char Word[15];
char *wordP=Word;
enum TokenType Kin;char WordS[15];
char* wordPS=WordS;
    char* ReservedWord[]={"and","array","begin","bool","call","case","char","constant","do","else","end","false","for","if","input","integer","not","of","or","output","procedure","program","read","real","repeat","set"
	,"then","to","true","until","var","while","write"};
	FILE *fp;
	union Element{
		           SYMBOL * pEntry;
		           enum Space spa;
		           int num; //temp var num or fourelemnum
		       };
	struct FourElement{
		                struct Token elem1;
		                union Element elem2;
		                union Element elem3;
		                union Element elem4;
		            }FElist[35]={0};
		            SYMBOL * pEntry=SymbolList; SYMBOL *I1,*I2;


 
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

/*int main(int argc, char *argv[]) {
	return 0;
}*/
void main() {  	
	// Turbo C2.0 original fp=fopen("test1.tst","r");
	fp=fopen("test1.txt","r");
	
	if(fp == NULL){
		perror("Error opening file");
		return -1;
	}
	SCANNER();
   
	// g t 250203  printf("(%d,%s)",i,tokArry);

	SYNDITER();
	fclose(fp);
}
   SCANNER()
   {
	   	ReadLine();

	   	/* g t	2025/1/29
		do
	   	{
	   	    FirstCh();
	   	    i++;
	   		toknum=i;  // g a 2015/1/30
	   		Sort();
		}while(ch!=feof(fp));  */
   
	   for(u=0;u<120;u++)
	 {
		  FirstCh();
	      if( ch!=feof(fp))
	   		{ 
				i++;
	   			toknum=i;  // g a 2015/1/30
	   			Sort();

			 // g t 250203  	printf("(%d,%s)",u,tokArry);
			}
	      else{
				 toknum=i;  // guang del 2015/2/3
				 break;
			}
		  //toknum=i;  // guang add 2015/2/3
         // g t 250203  printf("(%d,%s)",u,tokArry);
	 } 
   }
   ReadLine()
   { 
      printf("\n");
	  fgets(buff,LINELETH,fp);
	  printf("%3d: %s",++LineCnt,buff);
	} 
	FirstCh()
	{
		for(l=1;l<LINELETH;l++)
		{
			ch=buff[ColCnt++];
		//g t	printf("%3d: %c",ColCnt,ch);

			if(!isspace(ch))
			     break;
		    else if(ch=='\n')
		    {
		    	ColCnt=0;
		    	ReadLine();
		    	ch=buff[ColCnt++];break;
			}
		}	
	}
	Sort()
	{
		if(isalpha(ch))
		  RecogID();
		else if (ch=='/')
		          HandleCom();
		     else if(isdigit(ch))
		              RecogDig();
		          else if(ch==0x22)
		                   RecogStr();
		                else RecogDel();   
	 } 
	 RecogID()
	 {
	 	w=0;
	 	do{
	 		Word[w]=ch;
	 		++w;
	 		ch=buff[ColCnt++];
	 	}while(isalnum(ch)); 
		ch=buff[ColCnt--]; // g a 250203
	 	Word[w]=0;
	 	for(v=0;v<33;v++)
	 	{
	 		if(ReservedWord[v])
	 		{
	 		    if((strcmp(wordP,ReservedWord[v])==0))
	 		    {
	 		    	tokArry[i].code=++v;
	 		    	tokArry[i].Sval.space=_;
	 		    	printf("(%d,%d,_)",i,tokArry[i].code);
					 return(0);				 
			    }
		    }
		 }
		 tokArry[i].code=34;Kin=NUL;
		 LookUp();
		 printf("(%d,%d,%o)",i,tokArry[i].code,tokArry[i].Sval.entryP);
	 }
	 RecogDig()
	 {
	 	IntConst=ch-48;
	 	ch=buff[ColCnt++];
		while(isdigit(ch))
		{
			IntConst=IntConst*10+(ch-48);
			ch=buff[ColCnt++];
		}
		if(ch=='.')
		{
			int m=1;
			ch=buff[ColCnt++];
			while(isdigit(ch))
			{ 
			   m=10*m;
			   FloatConst=(float)(ch-48)/(float)m;
			   ch=buff[ColCnt++];
			   FloatConst+=IntConst;
			}
			ColCnt--; tokArry[i].code=36;
			LookUp();
			printf("(%d,%o)",tokArry[i].code,tokArry[i].Sval.entryP);
		}
		else
		{
			ColCnt--; // g a 250203
			tokArry[i].code=35;
			LookUp();
			printf("(%d,%d,%o)",i,tokArry[i].code,tokArry[i].Sval.entryP);
		}
	 }
	 HandleCom()
	 {
	 	char ch1;
	 	ch=buff[ColCnt++];
	 	if(ch!='*')
		{
			tokArry[++i].code=48;tokArry[i].Sval.space=_;
			printf("(%d,_)",tokArry[i].code);
			--ColCnt;
		}
		else
		{
			do
			{
				ch1=buff[ColCnt++];
				ch=buff[ColCnt++];
			}while(!(((ch1=='*')&&(ch=='/'))||ColCnt>29));
			if(ColCnt==30)
			{
					printf("comment doesnot end"); ch=ch1;
			}
			else {tokArry[++i].code=0;tokArry[i].Sval.space=_;//'0' represents a null token
			      printf("(%d,_)",tokArry[i].code);
			}
		}
	 }
	 RecogDel()
	 {
	 	switch(ch)
	 	{
	 		case'0x27':tokArry[i].code=38;tokArry[i].Sval.space=_;break;
	 		case'(':tokArry[i].code=39;tokArry[i].Sval.space=_;break;
	 		case')':tokArry[i].code=40;tokArry[i].Sval.space=_;break;
	 		case'*':tokArry[i].code=41;tokArry[i].Sval.space=_;break;
	 		case'+':tokArry[i].code=43;tokArry[i].Sval.space=_;break;
	 		case',':tokArry[i].code=44;tokArry[i].Sval.space=_;break;
	 		case'-':tokArry[i].code=45;tokArry[i].Sval.space=_;break;
	 		case'`':tokArry[i].code=46;tokArry[i].Sval.space=_;break;
	 		case'.':tokArry[i].code=47;tokArry[i].Sval.space=_;break;
	 		case'/':tokArry[i].code=48;tokArry[i].Sval.space=_;break;
	 		
	 		case':':{ch=buff[ColCnt++];
	 		         if(ch=='=')
	 		         {tokArry[i].code=51;tokArry[i].Sval.space=_;break;
					  }
					  else{--ColCnt;
					  tokArry[i].code=50;tokArry[i].Sval.space=_;break;
					  }
			 }
	 		case';':tokArry[i].code=52;tokArry[i].Sval.space=_;break;
		// g b o	case';':tokArry[i].code=52;tokArry[i].Sval.space=_;break;
	 		case'<':{ch=buff[ColCnt++];}
	 		         if(ch=='=')
	 		         {
					    tokArry[i].code=54;tokArry[i].Sval.space=_;break;
					  }
					  else if (ch=='>')
					  {
					    tokArry[i].code=55;tokArry[i].Sval.space=_;break;
					  }
					       else
					       {
					       	--ColCnt;
					       	tokArry[i].code=53;tokArry[i].Sval.space=_;break;
						   }
	 		case'=':tokArry[i].code=56;tokArry[i].Sval.space=_;break;
	 		case'>':{
			          ch=buff[ColCnt++];
					}
	 		         if(ch=='=')
	 		         {
					    tokArry[i].code=58;tokArry[i].Sval.space=_;break;
					}
					else{
					       	--ColCnt;
					       	tokArry[i].code=57;tokArry[i].Sval.space=_;break;
						}
						   
	 		case'#':tokArry[i].code=61;tokArry[i].Sval.space=_;break;
	 		default:return(0);  //"error, illeagl char"
		 }
		 printf("(%d,%d,_)",i,tokArry[i].code);
	 }
	 RecogStr()
	 {
	 	w=0;
	 	ch=buff[ColCnt++];
	 	do{
	 		WordS[w]=ch;
	 		++w;
	 		ch=buff[ColCnt++];
	 		}while(ch!=0x22);
	 		WordS[w]=0;
		 tokArry[i].code=37;Kin=chara;
		 LookUp();
		 printf("(%d,%o)",tokArry[i].code,tokArry[i].Sval.entryP);
	 }
	   LookUp()
	   {
	   	static int E,F;
		   if(tokArry[i].code ==34)
		   {
		   	for(E=0;E<=e;E++)
		   	 {
			   if(SymbolList[E].name.HeadP)
			     {
			     	if(((strcmp(wordP,SymbolList[E].name.HeadP))==0)&&(Kin==SymbolList[E].type))
	 		         {
	 		        	tokArry[i].Sval.entryP=&SymbolList[E];
					    return(0);				 
			         }
				 }
			 }
			   strcpy(pStrlistTail,wordP);
			   SymbolList[++e].name.HeadP=(pStrlistTail);
			   pStrlistTail=pStrlistTail+w+2;
			   SymbolList[e].name.IDlength=w+1;
			   SymbolList[e].type=NUL;
			   tokArry[i].Sval.entryP=&SymbolList[e];	   
			} 
			else if(tokArry[i].code ==37)
		   {
		   	 for(E=0;E<=e;E++)
		   	 {
			   if(SymbolList[E].name.HeadP)
			     {
			     	if(((strcmp(wordPS,SymbolList[E].name.HeadP))==0)&&(Kin==SymbolList[E].type))
	 		         {
	 		        	tokArry[i].Sval.entryP=&SymbolList[E];
					    return(0);				 
			         }
				 }
			 }
			   strcpy(pStrlistTail,wordPS);
			   SymbolList[++e].name.HeadP=(pStrlistTail);
			   pStrlistTail=pStrlistTail+w+2;
			   SymbolList[e].name.IDlength=w+1;
			   SymbolList[E].type=chara;
			   tokArry[i].Sval.entryP=&SymbolList[e];
		   }  
		   else if(tokArry[i].code ==35)
		   {
		   	 for(F=0;F<=e;F++)
		   	 {
			   if(IntConst==SymbolList[F].Uval.Ival&&SymbolList[F].kind==3)
			     
	 		         {
	 		        	tokArry[i].Sval.entryP=&SymbolList[F];
					    return(0);				 
			         }
			 }
			   SymbolList[++e].Uval.Ival=IntConst;
			   SymbolList[e].type=integer;
			   SymbolList[e].kind=digconst;
			   tokArry[i].Sval.entryP=&SymbolList[e];
		   }  
		   else
		   {
		   	 for(F=0;F<=e;F++)
		   	 {
			   if(FloatConst==SymbolList[F].Uval.Fval)
			     
	 		         {
	 		        	tokArry[i].Sval.entryP=&SymbolList[F];
	 		        	FloatConst=0;
					    return(0);				 
			         }
			 }
			   SymbolList[++e].Uval.Fval=FloatConst;FloatConst=0;
			   SymbolList[e].type=real;
			   tokArry[i].Sval.entryP=&SymbolList[e];
		   }  
	   }
	   
	   VARST();
	   IDS();
	   STL();
	   STSORT();
	   BACKPATCH();
	   MERG();
	   CONSTDEF();	
	   AEXP();
	   PushStk();
	   Recogtail();
	   Recoghead();
	   Action();
	   PushseStk();
	   BEXP();
	   BE();
	   BT();
	   BF();
	   GENCODE();
	   GetNext();
	   Fill();
	   IFS();
	   FORS();
	   WHILES();
	   REPEATS();
	   mPop();
	   PUSH();
	   EMPTY();
	   struct Token MTOP();
	   
	   NEWSTACK();
	   int Act,f,V;
	   int opfunction[2][7]={{2,9,5,5,9,9,9},{11,10,3,3,8,7,2}};
	   enum Actionnum {a,b,c,d,h};
	   enum OP{ID=34,left=39,right,miu,add=43,sub=45,dvid=48};//39  stands for the operater'('
	   enum Non_terminal {N};enum Non_terminal form_left_symbol;
	   struct formula{
	   	                enum Actionnum act;
	   	                struct Form_Right{
	   	                	union form_rightelem{ enum OP op;
	   	                	                      enum Non_terminal nt;}fre;
	   	                	int optag;}form_right[5];
					 }formlist[5]={{a,{{N,0},{43,1},{N,0}}},{b,{{N,0},{41,1},{N,0}}},{c,{{39,1},{N,0},{40,1}}},
					 {d,{{N,0},{45,1},{N,0}}},{h,{{N,0},{48,1},{N,0}}}};    //{c,{{N,0},{43,1},{N,0}}},???
						   
	   struct S_Stack{ int top;
	                       struct elemtype{
	                       	                union elem {enum Non_terminal reduce;
	                       	                struct Token in_tok;}et;
	                       	                int Ttag;
										  } elements[10];
					}Stk={0};   //Syntax_Stack
		int NXQ=1; int schain=0;int EPLACE;struct Token tok; int s1chain=0;
		struct S_Stack seStk={0};  //Semantics S_Stack
	   /*};
	   };
	   };*/
	   SYNDITER()
	   {
	   	  typedef struct{
	   	  	struct Token value;
	   	  	struct node * next;
			 }node;
			 typedef node * Stack;  Stack SK,stK;
		if(tokArry[k].code!=22)
		   printf("the program donot begin with 'program'");
		GetNext();
		if(tokArry[k].code!=34)
		     printf("lack of ID for program name");
        	 printf("(%d)",(tokArry[k].Sval.entryP)->kind);
	    (tokArry[k].Sval.entryP)->kind=program;
	       printf("(%d)",(*(tokArry[k].Sval.entryP)).kind);
	    GENCODE();
	    FElist[j].elem1.code=22; FElist[j].elem1.Sval.space=_;
	    FElist[j].elem2.pEntry = tokArry[k].Sval.entryP;
	    FElist[j].elem3.spa=_;
	    FElist[j].elem4.spa=_;
	         printf("(%d,(%d,%c),%o,%c,%c)\n",j,FElist[j].elem1.code, FElist[j].elem1.Sval.space,
			                                    FElist[j].elem2.pEntry,
												FElist[j].elem3.spa,
												FElist[j].elem4.spa);
			GetNext();
			if(tokArry[k].code!=52)
                  printf("lack of ';' has inserted");
            else GetNext();	
            if(tokArry[k].code!=31)
                  printf("lack of var");
            else GetNext();
			VARST();
			GetNext();
			STL();
		    GetNext();
		    if(tokArry[k].code!=47)
                  printf("lack of '.' inserted");
			else{
				  FElist[j].elem1.code=34;
			tokArry[++i].code =34;Kin=NUL;Word[0]='S';Word[1]='Y';
            Word[2]='S';Word[3]=0;
			LookUp();
			 printf("(%d,%d,%o)\n",i,tokArry[i].code,tokArry[i].Sval.entryP);		
			GENCODE();
			FElist[j].elem1.Sval.entryP=tokArry[i].Sval.entryP;
	    FElist[j].elem2.spa=_;
	    FElist[j].elem3.spa=_;
	    FElist[j].elem4.spa=_;
	         printf("(%d,%o,%c,%c,%c)\n",j,FElist[j].elem1.Sval.entryP,
			                                    FElist[j].elem2.spa,
												FElist[j].elem3.spa,
												FElist[j].elem4.spa);
			    }
		}
			VARST()
			{
				typedef struct node*Stack;  
				Stack stk,SK;
				if(tokArry[k].code!=34)	
				   printf("there is not any ID follows 'var'");	 
				else{
					SK=NEWSTACK();
					IDS(tokArry[k],SK);
				}
				GetNext();
			if((tokArry[k].code!=4)&&(tokArry[k].code!=7)&&(tokArry[k].code!=16)&&(tokArry[k].code!=24))
                  printf("illegal type statement");
            else GetNext();	
            if(tokArry[k].code!=52)
                  printf("there is not any ';' follows type statement");
            do{
            	Fill(MTOP());
            	mPop();	
			}while(!EMPTY());
			GetNext();
			if(tokArry[k].code!=3&&tokArry[k].code!=34)
                  printf(" there is not any var in varst or followed by 'begin'");
            else if (tokArry[k].code==34)
                     VARST(tokArry[k]);
                 else return(0);	
			}
		  typedef struct{
		  	struct Token value;
		  	struct node*next; 
		  }node;
		   typedef node*Stack;  Stack SK;     
		   IDS(T,SK)
		    struct Token T;Stack SK;
		   {
		    	PUSH(T,SK);
		    	GetNext();
		    	printf("(%d,%d)",k,tokArry[k].code);
			if(tokArry[k].code!=44&&tokArry[k].code!=50)
                  printf("there is not ',' or ':' in var sentence,has inserted");
            else if(tokArry[k].code==44)
            {
            	GetNext();	
            	if(tokArry[k].code!=34)
                  printf("there is not var in var sentence");
		    	else IDS(tokArry[k],SK);
			}
	      }
	      STL()
	      {
	      	if(tokArry[k].code==34||tokArry[k].code==14||tokArry[k].code==13||tokArry[k].code==3||tokArry[k].code==32||tokArry[k].code==25)
               {
               	schain=STSORT(tokArry[k]);
               	BACKPATCH(schain,NXQ);
               //* g b o 2525	
				printf("(%d,%o,%c,%c,%d)\n",16,FElist[16].elem1.Sval.entryP,
			                                    FElist[16].elem2.spa,
												FElist[16].elem3.spa,
												FElist[16].elem4.num);  //fourelem
				printf("(%d,%o,%o,%o,%d)\n",(21),FElist[21].elem1.Sval.entryP,
                FElist[21].elem2.pEntry,
				FElist[21].elem3.pEntry,
				FElist[21].elem4.num);  //fourelem
				printf("(%d,%o,%o,%d,%d)\n",(32),FElist[32].elem1.Sval.entryP,
                FElist[32].elem2.pEntry,
				FElist[32].elem3.num,
				FElist[32].elem4.num);  //fourelem   //*/
				GetNext();
				 STL(tokArry[k]);
			   }  
            else if(tokArry[k].code!=11)
                     printf("illegal or lack of end");
            return(0);	
		  }
			      
		STSORT(T)
		  struct Token T;
		  {
		  	switch(tokArry[k].code)
		  	{
		  		case 8: CONSTDEF();break;
		  		case 34:{
		  			g=k;
		  			GetNext();
		  			if(tokArry[k].code!=51)
                        printf("lack of :=  inserted");
                    if(tokArry[k+2].code==52 ||tokArry[k+2].code==28)
                    { 
                        GENCODE();
                        printf("(%d,(%d),%o,_,%o)\n",j,51,tokArry[k+1].Sval.entryP,tokArry[k-1].Sval.entryP);
                        k=k+2;
                    }
                    else
                    {  AEXP();
                       GENCODE();
                       FElist[j].elem1.code=51; FElist[j].elem1.Sval.space=_;
						FElist[j].elem2.num = f;
						FElist[j].elem3.spa=_;
						FElist[j].elem4.pEntry=tokArry[g].Sval.entryP;  //reduce:iA:=E
						
	                   printf("(%d,(%d,%c),%d,%c,%o)\n",j,FElist[j].elem1.code, 
					                            FElist[j].elem1.Sval.space,
			                                    FElist[j].elem2.num,
												FElist[j].elem3.spa,
												FElist[j].elem4.pEntry);
					}
					schain=0;
					break;
				  }
				case 13:schain=FORS();break;
				case 14:schain=IFS();break;
				case 32:WHILES();break;
				case 25:REPEATS();break;
				case 3:
					{
					  GetNext();
					  STL(tokArry[k]);
					  schain=0;
					};break;
				default : printf("illegal head ch");
			  }
			  return(schain);
		  }		
		  IFS()
		  {
		  	int schain,s1chain,S5CHAIN,Tchain,TCHAIN,q;
			BEXP();
			BACKPATCH(BFTC,NXQ);
		  	printf("(%d,%o,%o,%o,%d)\n",(j-1),FElist[j-1].elem1.Sval.entryP,
            FElist[j-1].elem2.pEntry,
			FElist[j-1].elem3.pEntry,
			FElist[j-1].elem4.num);  //fourelem
			GetNext();
			if(tokArry[k].code!=27)
                    printf("error,lack of 'then' has inserted");
            GetNext();
			s1chain=STSORT(tokArry[k].code);
			if(tokArry[k].code==10)
			{
				q=NXQ;
				FElist[j].elem1.code=34;tokArry[++i].code=34;Kin=NUL;
				Word[0]='j';Word[1]=0;
				LookUp();
				GENCODE();
				FElist[j].elem1.Sval.entryP=tokArry[i].Sval.entryP;
			    FElist[j].elem2.spa=_;
			    FElist[j].elem3.spa=_;
			    FElist[j].elem4.num=0;
	            printf("(%d,%o,%c,%c,%d)\n",(j),FElist[j].elem1.Sval.entryP,
			                                    FElist[j].elem2.spa,
												FElist[j].elem3.spa,
												FElist[j].elem4.num);
				BACKPATCH(BTFC,NXQ);
				printf("(%d,%o,%c,%c,%d)\n",(13),FElist[13].elem1.Sval.entryP,
			                                    FElist[13].elem2.spa,
												FElist[13].elem3.spa,
												FElist[13].elem4.num);
					//fourelem
				printf("(%d,%o,%c,%c,%d)\n",(11),FElist[11].elem1.Sval.entryP,
                FElist[11].elem2.spa,
				FElist[11].elem3.spa,
				FElist[11].elem4.num);
				//fourelem
				Tchain=MERG(s1chain,q);
				GetNext();
			    S5CHAIN=STSORT();
			    schain=MERG(Tchain,S5CHAIN);
			    return(schain);
			}  
			else return(MERG(s1chain,BFFC));        
		  }								
	   
		    FORS()
		    {
		    	int y,q,T1,E1place, E2place, Fplace, Fagain,Fchain;
		    	GetNext();y=k;
		    	Fplace=tokArry[k].Sval.entryP;
		    	STSORT(tokArry[k].code);
		    	if(tokArry[k].code!=28)
                    printf("error,lack of 'to'");
	            T1=newt();
	            GetNext();
				if(tokArry[k+1].code==9)
				{
					E2place=(tokArry[k].Sval.entryP);
					GENCODE();
					FElist[j].elem1.code =51;FElist[j].elem1.Sval.space=_;
				    FElist[j].elem2.pEntry=E2place;
				    FElist[j].elem3.spa=_;
				    FElist[j].elem4.num=T1;
				    printf("(%d,(%d,%c),%o,%c,%d)\n",j,FElist[j].elem1.code, FElist[j].elem1.Sval.space,
			                                    FElist[j].elem2.pEntry,
												FElist[j].elem3.spa,
												FElist[j].elem4.num);
				}
				else
				{
					AEXP();
					GENCODE();
                       FElist[j].elem1.code=51; FElist[j].elem1.Sval.space=_;
					    FElist[j].elem2.num=f;
					    FElist[j].elem3.spa=_;
					    FElist[j].elem4.pEntry=tokArry[g].Sval.entryP;  //reduce:iA:=E
	                     printf("(%d,(%d,%c),%d,%c,%o)\n",j,FElist[j].elem1.code, 
					                            FElist[j].elem1.Sval.space,
			                                    FElist[j].elem2.num,
												FElist[j].elem3.spa,
												FElist[j].elem4.pEntry);
					}
					
					q=NXQ;
				FElist[j].elem1.code=34;tokArry[++i].code=34;Kin=NUL;
				Word[0]='j';Word[1]=0;
				LookUp();
				GENCODE();
				FElist[j].elem1.Sval.entryP=tokArry[i].Sval.entryP;
			    FElist[j].elem2.spa=_;
			    FElist[j].elem3.spa=_;
			    FElist[j].elem4.num=q+2;
	            printf("(%d,%o,%c,%c,%d)\n",(j),FElist[j].elem1.Sval.entryP,
			                                    FElist[j].elem2.spa,
												FElist[j].elem3.spa,
												FElist[j].elem4.num);
				Fagain=q+1;
				tokArry[++i].code=35;IntConst=1;
				LookUp();
				GENCODE();
                       FElist[j].elem1.code=43; FElist[j].elem1.Sval.space=_;
					    FElist[j].elem2.pEntry = Fplace;
					    FElist[j].elem3.pEntry=tokArry[i].Sval.entryP;
					    FElist[j].elem4.pEntry=Fplace;  
	                     printf("(%d,(%d,%c),%o,%o,%o)\n",j,FElist[j].elem1.code, 
							                    FElist[j].elem1.Sval.space,   //lost 202526
			                                    FElist[j].elem2.pEntry,
												FElist[j].elem3.pEntry,
					                            FElist[j].elem4.pEntry);
				Fchain=NXQ;
				FElist[j].elem1.code=34;tokArry[i].code=34;Kin=NUL;
				Word[0]='j';Word[1]='>';Word[2]=0;
				LookUp();
				GENCODE();
				FElist[j].elem1.Sval.entryP=tokArry[i].Sval.entryP;
			    FElist[j].elem2.pEntry=Fplace;
			    FElist[j].elem3.num=T1;
			    FElist[j].elem4.num=0;
	            printf("(%d,%o,%o,%d,%d)\n",j,FElist[j].elem1.Sval.entryP,
			                                    FElist[j].elem2.pEntry,
												FElist[j].elem3.num,
												FElist[j].elem4.num);
				GetNext();
				if(tokArry[k].code!=9)
                    printf("error,lack of 'do'");
	            GetNext();
				s1chain=STSORT(tokArry[k].code);							
				BACKPATCH(s1chain,Fagain);
				
				FElist[j].elem1.code=34;tokArry[++i].code=34;Kin=NUL;
				Word[0]='j';Word[1]=0;
				LookUp();
				GENCODE();
				FElist[j].elem1.Sval.entryP=tokArry[i].Sval.entryP;
				FElist[j].elem2.spa=_;
			    FElist[j].elem3.spa=_;
			    FElist[j].elem4.num=Fagain;
	            printf("(%d,%o,%c,%c,%d)\n",j,FElist[j].elem1.Sval.entryP,
			                                    FElist[j].elem2.spa,
												FElist[j].elem3.spa,
												FElist[j].elem4.num);
				schain=Fchain;  // g b error  2526  Fagain;
			    return(schain);
			}
	WHILES()
	{
		int s2chain,s3chain;
		int Whead=NXQ; 
		BEXP();
			BACKPATCH(BFTC,NXQ);
		  	printf("(%d,%o,%o,%o,%d)\n",(j-1),FElist[j-1].elem1.Sval.entryP,
            FElist[j-1].elem2.pEntry,
			FElist[j-1].elem3.pEntry,
			FElist[j-1].elem4.num);  //fourelem
			GetNext();
			if(tokArry[k].code==9)
            GetNext();
			s3chain=STSORT(tokArry[k].code);
			s2chain=MERG(s3chain,NXQ);
		
				FElist[j].elem1.code=34;tokArry[++i].code=34;Kin=NUL;
				Word[0]='j';Word[1]=0;
				LookUp();
				GENCODE();
				FElist[j].elem1.Sval.entryP=tokArry[i].Sval.entryP;
			    FElist[j].elem2.spa=_;
			    FElist[j].elem3.spa=_;
			    FElist[j].elem4.num=0;
	            printf("(%d,%o,%c,%c,%d)\n",(j),FElist[j].elem1.Sval.entryP,
			                                    FElist[j].elem2.spa,
												FElist[j].elem3.spa,
												FElist[j].elem4.num);
				BACKPATCH(s2chain,Whead);
				printf("(%d,%o,%c,%c,%d)\n",(j),FElist[j].elem1.Sval.entryP,
			                                    FElist[j].elem2.spa,
												FElist[j].elem3.spa,
												FElist[j].elem4.num);
					//fourelem
				BACKPATCH(BFFC,NXQ);
				printf("(%d,%o,%c,%c,%d)\n",(24),FElist[24].elem1.Sval.entryP,
                FElist[24].elem2.spa,
				FElist[24].elem3.spa,
				FElist[24].elem4.num);
		}	
	REPEATS()
	{
	    int Rhead=NXQ;
	    GetNext();
		s1chain=STSORT();
		if(tokArry[k].code!=30)
	            printf("error,lack of 'until'");
	    else{
	    	BACKPATCH(s1chain,NXQ);
	    	BEXP();
		    BACKPATCH(BTFC,Rhead);
		    printf("(%d,%o,%c,%c,%d)\n",(22),FElist[22].elem1.Sval.entryP,
		                                    FElist[22].elem2.spa,
											FElist[22].elem3.spa,
											FElist[22].elem4.num);
			schain=BTTC;
		}
	}
		BACKPATCH(P,t)
		     int P,t;
	    {
	    	int Q=0;int q=0;
	    	Q=P;
	    	while(Q!=0)
	    	{   
			    q=FElist[Q].elem4.num;   //fourelemnum;
		    	FElist[Q].elem4.num=t;
		    	Q=q;
			}
		 } 
		 
		MERG(p1,p2)
		      int p1,p2;
		{
		    int p;
		    if(p2==0)
		        return(p1);
		    else{
		    	p=p2;
		    while(FElist[p].elem4.num!=0)
		          {
					p=FElist[p].elem4.num;
				  }
					FElist[p].elem4.num=p1;
					return(p2);
			   }
		}
		GENCODE()
		{
			++NXQ;
			++j;
		}
		GetNext()
		{
			if(k<toknum)
			     ++k;
		}
		struct Token elm;
	NEWSTACK()
		// g b o	NEWSTACK() 
		{
			Stack s1;

			//  LEN = sizeof(Stack);  // g t 
	    	s1=(Stack)malloc(LEN);
				//g b t also worked	s1=(Stack)malloc(sizeof(Stack));
			s1->next=0;
			return(s1);
		}
       PUSH(elm,stk)
	      struct Token elm;Stack stk;
		  {
		  	Stack s;
		  	  s=(Stack)malloc(LEN);
		  	s->value=elm;
		  	s->next=stk->next;
		  	stk->next=s;
		  	printf("(%d,%o)",s->value.code,(s->value).Sval.entryP);
		  	return(stk);
		 }		
mPop(stk)
    Stack stk;
    {
    	Stack s;
    	if(stk->next){
    		s=stk->next;
    		stk->next=s->next;
		}
	}
struct Token MTOP(stk)
      Stack stk;
    { struct Token y;
      Stack s4;
      if(stk->next!=0)
      {s4=stk->next;
       y=s4->value;
	  }
	  return(y);
	}
EMPTY(stk)
    Stack stk;
    {
    	if(stk->next)
    		return(0);
    	else
    	    return(1);
	}
Fill(z)
struct Token z;
{ //g b o 2524	printf("(%d)",(tokArry[5].Sval.entryP)->type);
    switch(tokArry[k-1].code)
    {
    /* g b o 202524	case 4: ((z).Sval.entryP)->type=boolen;break;
    	case 7: ((z).Sval.entryP)->type=chara;break;
    	case 16: ((z).Sval.entryP)->type=integer;break;
    	default: ((z).Sval.entryP)->type=real;  */

		case 4: (z).code=4;break;
    	case 7: (z).code=7;break;
    	case 16: (z).code=16;break;
    	default: (z).code=24;
    }
    	(z).Sval.space=_;
    //g b o 250204	printf("(%d)",(tokArry[5].Sval.entryP)->type);
}
CONSTDEF()
{
		if(tokArry[k+1].code==35)
	    {
	    	(tokArry[k-1].Sval.entryP)->Uval.Ival =(tokArry[k+1].Sval.entryP)->Uval.Ival;  // original Iva???
           	(tokArry[k-1].Sval.entryP)->type=integer;
           	(tokArry[k-1].Sval.entryP)->kind=digconst;
		   }
	    else if(tokArry[k+1].code==37){
	    	(tokArry[k-1].Sval.entryP)->Uval.entry = tokArry[k+1].Sval.entryP;  
           	(tokArry[k-1].Sval.entryP)->type=chara;
           	(tokArry[k-1].Sval.entryP)->kind=chconst;	
		}
		k=k+2;
}
AEXP()
{int tail;
Stk.top =9;//initialize
Stk.elements[Stk.top].et.in_tok.code =61;
Stk.elements[Stk.top].et.in_tok.Sval.space=_;
GetNext();
PushStk();
pushseStk();
do
{
	Recoghead(Recogtail());
	}while(tokArry[k].code!=52&&tokArry[k].code!=10&&tokArry[k].code!=30);
}
	int Recogtail()
	{
		int tail,j,m,h;
		for(;;)
		{
			GetNext();
		if(tokArry[k].code==10||tokArry[k].code==30)
	        {
			  tail=Stk.top;
			  --k;
			  return(tail);	   	
			}
		else if(Stk.elements[Stk.top].Ttag==1)
		        tail=Stk.top;
		    else tail=Stk.top+1;
		    m=change(Stk.elements[tail].et.in_tok.code);
		    h=change(tokArry[k].code);
		    if(opfunction[0][m]<=opfunction[1][h])
		    {PushStk();
		    pushseStk();
			}
			else break;
		}
		--k;
		return(tail);
	}
	Recoghead(t)
	int t;
	{int U,n,l,y,r,num,lower,upper;//upper stands for the upper terminator
	 int z=0;
	 lower=t;
	 do{
	 	upper=lower;
	 	++lower;
	 	if(Stk.elements[lower].et.in_tok.code==61)
	 	{
	 		Stk.elements[Stk.top].et.reduce =form_left_symbol;
	 		Stk.elements[Stk.top].Ttag =0;
	 		EPLACE=seStk.elements[Stk.top].et.in_tok.Sval.entryP;
	 		GetNext();
			PushStk();
			pushseStk();
			//f->i;
			return(0);
		 }
		 else if(Stk.elements[lower].Ttag!=1)
		         lower+=1;
		if(lower==9)
		{
			break;
		}
		n=change(Stk.elements[lower].et.in_tok.code);
		l=change(Stk.elements[upper].et.in_tok.code);
		// g b e l=change(tokArry[upper].code);
		}while(opfunction[0][n]>opfunction[1][l]);
		    l=lower-Stk.top+1;
		if(l==2)
	 	{
	 		Stk.elements[Stk.top].et.reduce =form_left_symbol;  //push N
	 		Stk.elements[Stk.top].Ttag =0;
			//f->i;
			return(0);
		}
		--lower;
		for(;;)
		{
			for(y=0;y<=3;y++)
			{z=0;
			  for(num=lower;num>=Stk.top ;num--)
			  {
			  	if((Stk.elements[num].Ttag ==0&&formlist[y].form_right[z].optag ==0)||(Stk.elements[num].Ttag ==1&&formlist[y].form_right[z].optag ==1&&Stk.elements[num].et.in_tok.code==formlist[y].form_right[z].fre.op))
			  	              ++z;
			    else  break;
			  }
			  if(num==Stk.top-1)
			  {
			  	Stk.top=Stk.top+2;
			    Stk.elements[Stk.top].et.reduce =form_left_symbol;  //push N
	 		    Stk.elements[Stk.top].Ttag =0;	
	 		    Act=formlist[y].act;
	 		    V=Stk.top;
	 		    Action(Act);
	 		    seStk.elements[Stk.top].Ttag=f;
			  	break;
			  }
			}
		    lower+=1;
		    GetNext();
		    if(tokArry[k].code==10)
	 	    {
	 		   return(s1chain);
		    }
			else if(lower==9)
			{
				PushStk();
				pushseStk();
				return(0);
			}
			n=change(Stk.elements[lower].et.in_tok.code);
			l=change(tokArry[k].code);
			if(opfunction[0][n]<=opfunction[1][l])
			{
				PushStk();
				pushseStk();
			}
			else {--k;break;}
		}
	  }  
	  int change(code)
	  {int r;
	  switch(code)
	  {
	  	case 39: r=0;break;
	  	case 34: r=1;break;
	  	case 43: r=2;break;
	  	case 45: r=3;break;
	  	case 41: r=4;break;
	  	case 48: r=5;break;
	  	default: r=6;
	  }
	    return(r);
	  }
	  Action(A)
	   {
		  int pPLACE;
	      switch(A)
			  {
			  	case a: newt();
			  	        GENCODE();
		  	            FElist[j].elem1.code=43; FElist[j].elem1.Sval.space=_;
					    FElist[j].elem2.pEntry = seStk.elements[V].et.in_tok.Sval.entryP;
					    FElist[j].elem3.pEntry= seStk.elements[V-2].et.in_tok.Sval.entryP;
					    FElist[j].elem4.num=f;  
		                printf("(%d,(%d,%c),%o,%o,%d)\n",j,FElist[j].elem1.code, 
		                                        FElist[j].elem1.Sval.space,
			                                    FElist[j].elem2.pEntry,
												FElist[j].elem3.pEntry,
					                            FElist[j].elem4.num);
					    break;//e->E+T
				case b: newt();
			  	        GENCODE();
		  	            FElist[j].elem1.code=41; FElist[j].elem1.Sval.space=_;
					    FElist[j].elem2.pEntry = seStk.elements[Stk.top].et.in_tok.Sval.entryP;
					    FElist[j].elem3.num= seStk.elements[Stk.top-2].Ttag;
					    FElist[j].elem4.num=f;  
		                printf("(%d,(%d,%c),%o,%d,%d)\n",j,FElist[j].elem1.code, 
		                                        FElist[j].elem1.Sval.space,
			                                    FElist[j].elem2.num,
												FElist[j].elem3.num,
					                            FElist[j].elem4.num);
					    break;//e->E*T
				case c:	break;//p->(E);    	    
			    case d: newt();
				        GENCODE();
				        FElist[j].elem1.code=45; FElist[j].elem1.Sval.space=_;
					    FElist[j].elem2.pEntry = seStk.elements[V].et.in_tok.Sval.entryP;
					    FElist[j].elem3.pEntry= seStk.elements[V-2].et.in_tok.Sval.entryP;
					    FElist[j].elem4.num=f;  
				        printf("(%d,(%d,%c),%o,%o,%d)\n",j,FElist[j].elem1.code, 
				                                FElist[j].elem1.Sval.space,
				                                FElist[j].elem2.pEntry,
												FElist[j].elem3.pEntry,
					                            FElist[j].elem4.num);
					    break;//e->E-T
				case h: newt();
			  	        GENCODE();
		  	            FElist[j].elem1.code=48; FElist[j].elem1.Sval.space=_;
					    FElist[j].elem2.pEntry = seStk.elements[Stk.top].et.in_tok.Sval.entryP;
					    FElist[j].elem3.num= seStk.elements[Stk.top-2].Ttag;
					    FElist[j].elem4.num=f;  
		                printf("(%d,(%d,%c),%o,%d,%d)\n",j,FElist[j].elem1.code, 
                                        FElist[j].elem1.Sval.space,
	                                    FElist[j].elem2.num,
										FElist[j].elem3.num,
			                            FElist[j].elem4.num);
  	         }      
	  }
	  PushStk()
	  {
	  	Stk.top-=1;Stk.elements[Stk.top].Ttag =1; 
		Stk.elements[Stk.top].et.in_tok =tokArry[k];
	}
	
	pushseStk()
	{
		seStk.elements[Stk.top].et.in_tok=Stk.elements[Stk.top].et.in_tok;
	}
	newt()
	{
		f=f+1;
	}

	BEXP(){
	     GetNext();
		 BE();
	}
    BE()
    {
    	if(tokArry[k].code==17||tokArry[k].code==39||tokArry[k].code==34)
               {
	           	 BT();
	           	 if(tokArry[k].code!=19)
	                 return(0);
                 else{
	                 	BACKPATCH(BTFC,NXQ);
	                 	GetNext();
	                 	BE();
	                 	BETC=MERG(BETC,BTTC); 	
					}
        return(0);
	           }
	}
	BT()
	{
			if(tokArry[k].code==17||tokArry[k].code==39||tokArry[k].code==34)
               {
	           	 BF();
	           	 if(tokArry[k].code!=1)
	                {
					 BTTC=BFTC;
					 BTFC=BFFC;
					 return(0);
					} 
                 else{
	                 	BACKPATCH(BFTC,NXQ);
	                 	 printf("(%d,%o,%o,%c,%d)\n",(10),FElist[10].elem1.Sval.entryP,
			                                    FElist[10].elem2.pEntry,
												FElist[10].elem3.spa,
												FElist[10].elem4.num);
	                 	BFFC1=BFFC;
	                 	GetNext();
	                 	BT();
	                 	BTFC=MERG(BFFC1,BFFC); 	
					}
                    return(0);
			   }
	}
	BF()
	{
	  switch(tokArry[k].code)
	  {
	  	case 17: GetNext();
             	 BF();
             	 BFTC=BF1FC;BFFC=BF1TC; break;
	  	case 39: {
	  	        	GetNext();
             	    BE();
             	    GetNext();
             	    if(tokArry[k].code!=40)
	                 
					  printf("err,lack of ')'");break;
		        }
	  	case 34: {
			  		I1=tokArry[k].Sval.entryP;
				    GetNext();
		     	    if(tokArry[k].code==53||tokArry[k].code==54||tokArry[k].code==56||tokArry[k].code==57||tokArry[k].code==58||tokArry[k].code==55)
		            {  
					GetNext();
					if(tokArry[k].code!=34)
			                 printf("terr");
			        else{ 	I2=tokArry[k].Sval.entryP;
						//	}
				    BFTC=NXQ;
				    FElist[j].elem1.code=34;tokArry[i].code=34;Kin=NUL;
						Word[0]='j';
					switch(tokArry[k-1].code)
					  {
					  	case 53: Word[1]='<';Word[2]=0;break;
						case 54: Word[1]='<';Word[2]='=';Word[3]=0;break;
						case 55: Word[1]='<';Word[2]='>';Word[3]=0;break;
			  	        case 56: Word[1]='=';Word[2]=0;break;
			  	        case 57: Word[1]='>';Word[2]=0;break;
						case 58: Word[1]='>';Word[2]='=';Word[3]=0;break;
			          }
			          LookUp();
			    	printf("(%d,%d,%o)\n",i,tokArry[i].code,tokArry[i].Sval.entryP);
			    	GENCODE();
					FElist[j].elem1.Sval.entryP=tokArry[i].Sval.entryP;
		            FElist[j].elem2.pEntry=I1;
					FElist[j].elem3.pEntry=I2;
					FElist[j].elem4.num=0;  //fourelem
					printf("(%d,%o,%o,%o,%d)\n",j,FElist[j].elem1.Sval.entryP,
		            FElist[j].elem2.pEntry,
					FElist[j].elem3.pEntry,
					FElist[j].elem4.num);  //fourelem
					BFFC=NXQ;
					FElist[j].elem1.code=34;tokArry[++i].code=34;Kin=NUL;
					Word[0]='j';Word[1]=0;
					LookUp();
					
					printf("(%d,%d,%o)\n",i,tokArry[i].code,tokArry[i].Sval.entryP);
			    	GENCODE();
					FElist[j].elem1.Sval.entryP=tokArry[i].Sval.entryP;
		            FElist[j].elem2.spa=_;
					FElist[j].elem3.spa=_;
					FElist[j].elem4.num=0;  //fourelem
					
					printf("(%d,%o,%c,%c,%d)\n",j,FElist[j].elem1.Sval.entryP,
		            FElist[j].elem2.spa,
					FElist[j].elem3.spa,
					FElist[j].elem4.num);  
						}
					}
					else
					{
							BFTC=NXQ;
							FElist[j].elem1.code=34;tokArry[++i].code=34;Kin=NUL;
							Word[0]='j';Word[1]='n'; Word[2]='z';Word[3]= 0;
							LookUp();
					
					printf("(%d,%d,%o)\n",i,tokArry[i].code,tokArry[i].Sval.entryP);
			    	GENCODE();
					FElist[j].elem1.Sval.entryP=tokArry[i].Sval.entryP,
		            FElist[j].elem2.pEntry=I1;
					FElist[j].elem3.spa=_;
					//FElist[j-1].elem4.num=0;  //fourelem
					FElist[j].elem4.num=0;  //fourelem
					printf("(%d,%o,%o,%c,%d)\n",j,FElist[j].elem1.Sval.entryP,
		            FElist[j].elem2.pEntry,
					FElist[j].elem3.spa,
					FElist[j].elem4.num);  //fourelem
					BFFC=NXQ;
					FElist[j].elem1.code=34;tokArry[++i].code=34;Kin=NUL;
					Word[0]='j';Word[1]=0;
					LookUp();
					
					printf("(%d,%d,%o)\n",i,tokArry[i].code,tokArry[i].Sval.entryP);
			    	GENCODE();
					FElist[j].elem1.Sval.entryP=tokArry[i].Sval.entryP;
		            FElist[j].elem2.spa=_;
					FElist[j].elem3.spa=_;
					FElist[j].elem4.num=0;  //fourelem
					printf("(%d,%o,%c,%c,%d)\n",11,FElist[j].elem1.Sval.entryP,
		            FElist[j].elem2.spa,
					FElist[j].elem3.spa,
					FElist[j].elem4.num);  //fourelem
					}		
				}
	   }
			
	}
	